package com.assignment.payrollengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayrollengineApplicationTests {

    @Test
    void contextLoads() {
    }

}
