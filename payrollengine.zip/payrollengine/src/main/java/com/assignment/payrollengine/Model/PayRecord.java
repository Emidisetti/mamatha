package com.assignment.payrollengine.Model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Getter
@Setter
@AllArgsConstructor
@Document(collection = "pay_record")
public class PayRecord {
    @Id
    private long id;
    private long employeeId;
    private long netPay;
    private long period;
}
