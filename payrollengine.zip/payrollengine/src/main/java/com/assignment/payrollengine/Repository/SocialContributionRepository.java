package com.assignment.payrollengine.Repository;

import com.assignment.payrollengine.Model.SocialContribution;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SocialContributionRepository extends MongoRepository<SocialContribution, Long> {
}
