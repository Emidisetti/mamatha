package com.assignment.payrollengine.Model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "social_contribution")
public class SocialContribution {

    private int percentage;
    private long period;
}
