package com.assignment.payrollengine.Controller;

import com.assignment.payrollengine.Model.Employee;
import com.assignment.payrollengine.Model.PayRecord;
import com.assignment.payrollengine.Service.PayRollEngineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
public class PayRollEngineController {

    @Autowired
    private PayRollEngineService payRollEngineService;

    @PostMapping(value = "/employee")
    public Employee createEmployee(@Valid @RequestBody Employee employee){
        Employee createdEmployee = payRollEngineService.createEmployee(employee);
        return createdEmployee;
    }

    @PutMapping(value = "/employee")
    public Employee updateEmployee(@RequestBody Employee employee){
        Employee updatedEmployee = payRollEngineService.updateEmployee(employee);
        return updatedEmployee;
    }

    @GetMapping(value = "/allEmployees")
    public List<Employee> getAllEmployees(){
        return payRollEngineService.getAllEmployees();
    }

    @GetMapping(value = "/employee/{id}")
    public Optional<Employee> getEmployee(@PathVariable("id") long id){
        return payRollEngineService.getEmployee(id);
    }

    @GetMapping(value = "/employeesDuringGivenPeriod")
    public List<Employee> getEmployeesDuringGivenPeriod(@RequestParam(
            name = "startDate") int startDate, @RequestParam(name = "endDate") int endDate){
    return payRollEngineService.getEmployeesDuringGivenPeriod(startDate, endDate);
    }

    @PostMapping(value = "/payroll")
    public List<PayRecord> createPayRecordForEmployees(
            @RequestBody List<Employee> employeeList,
            @RequestParam(name = "period") int period){
        return payRollEngineService.createPayRecordForEmployees(employeeList, period);
    }
}
