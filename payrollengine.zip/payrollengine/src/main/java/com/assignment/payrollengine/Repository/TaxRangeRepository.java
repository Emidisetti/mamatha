package com.assignment.payrollengine.Repository;

import com.assignment.payrollengine.Model.TaxRange;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TaxRangeRepository extends MongoRepository<TaxRange, Long> {
}
