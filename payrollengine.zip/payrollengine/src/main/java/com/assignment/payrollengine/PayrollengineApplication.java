package com.assignment.payrollengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayrollengineApplication {

    public static void main(String[] args) {
        SpringApplication.run(PayrollengineApplication.class, args);
    }

}
