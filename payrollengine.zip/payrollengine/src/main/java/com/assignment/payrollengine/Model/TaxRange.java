package com.assignment.payrollengine.Model;

import lombok.Data;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document(collection = "tax_range")
public class TaxRange {

    private long lowerSemitNetTaxThreshold;
    private long upperSemitNetTaxThreshold;
    private int salaryTaxPercentage;
}
