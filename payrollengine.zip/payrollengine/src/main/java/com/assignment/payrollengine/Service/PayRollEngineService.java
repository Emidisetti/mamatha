package com.assignment.payrollengine.Service;

import com.assignment.payrollengine.Model.Employee;
import com.assignment.payrollengine.Model.PayRecord;
import com.assignment.payrollengine.Model.SocialContribution;
import com.assignment.payrollengine.Model.TaxRange;
import com.assignment.payrollengine.Repository.EmployeeRepository;
import com.assignment.payrollengine.Repository.PayRecordRepository;
import com.assignment.payrollengine.Repository.SocialContributionRepository;
import com.assignment.payrollengine.Repository.TaxRangeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.management.Query;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PayRollEngineService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PayRecordRepository payRecordRepository;

    @Autowired
    private SocialContributionRepository socialContributionRepository;

    @Autowired
    private TaxRangeRepository taxRangeRepository;

    public List<Employee> getAllEmployees(){
        return employeeRepository.findAll();
    }

    public Employee createEmployee(Employee employee){
        Employee createdEmployee = employeeRepository.insert(employee);
        return createdEmployee;
    }

    public Employee updateEmployee(Employee employee){
        Employee updatedEmployee = employeeRepository.save(employee);
        return updatedEmployee;
    }

    public Optional<Employee> getEmployee(long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        return employee;
    }

    public List<Employee> getEmployeesDuringGivenPeriod(int startDate, int endDate){
        List<Employee> employeeList = employeeRepository.findAll();
        List<Employee> filteredEmployeeList = employeeList.stream().filter(
                s -> s.getEmploymentStartDate() >= startDate &&
                        s.getEmploymentEndDate() <= endDate
        ).collect(Collectors.toList());
        return filteredEmployeeList;
    }

    public List<PayRecord> createPayRecordForEmployees(List<Employee> employeeList, int period) {

        int socialContributionPercentage = getSocialContribution(period);
        List<TaxRange> taxRangeList = getTaxRangeList();
        List<PayRecord> payRecordList = new ArrayList<>();
        for(Employee employee : employeeList){
            long grossSalary = employee.getGrossSalary();
            long semiNet = calculateSemiNet(grossSalary, socialContributionPercentage);
            int salaryTaxPercentage = 0;
            for(TaxRange taxRange : taxRangeList){
                if(grossSalary > taxRange.getLowerSemitNetTaxThreshold()
                        && grossSalary < taxRange.getUpperSemitNetTaxThreshold()){
                    salaryTaxPercentage = taxRange.getSalaryTaxPercentage();
                }
            }
            long salaryTaxAmount = calculateSalaryTaxAmount(grossSalary, salaryTaxPercentage);
            long netPay = semiNet - salaryTaxAmount;
            PayRecord payRecord = new PayRecord(employee.getId(), employee.getEmployeeId(),
                    netPay, period);
            payRecordList.add(payRecord);
        }
        return payRecordRepository.saveAll(payRecordList);
    }

    private long calculateSalaryTaxAmount(long grossSalary, int salaryTaxPercentage) {
        long deduction = (salaryTaxPercentage * grossSalary)/100;
        return deduction;
    }

    private long calculateSemiNet(long grossSalary, int socialContributionPercentage) {
        long deduction = (socialContributionPercentage * grossSalary)/100;
        return grossSalary - deduction;
    }

    public int getSocialContribution(int period){
        List<SocialContribution> socialContributionList = 
                socialContributionRepository.findAll();
        int socialContributionPercentage = 0;
        
        for (SocialContribution socialContribution: socialContributionList){
            if(socialContribution.getPeriod() == period){
                socialContributionPercentage = socialContribution.getPercentage();
            }
        }
        return socialContributionPercentage;
    }

    public List<TaxRange> getTaxRangeList(){
        return taxRangeRepository.findAll();
    }
}
