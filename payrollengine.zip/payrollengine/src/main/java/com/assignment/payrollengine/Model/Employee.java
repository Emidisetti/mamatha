package com.assignment.payrollengine.Model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@Getter
@Setter
@AllArgsConstructor
@Document(collection = "employee")
public class Employee {

    @Id
    private long id;
    private long employeeId;

    private String employeeName;
    private String company;

    @NonNull
    private long grossSalary;

    private long employmentStartDate;
    private long employmentEndDate;

}
